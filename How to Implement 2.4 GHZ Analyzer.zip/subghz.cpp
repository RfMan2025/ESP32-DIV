#include "subconfig.h"
#include "shared.h"
#include "icon.h"
#include "Touchscreen.h"

/*
 * ReplayAttack
 * 
 * 
 * 
 */

namespace replayat {

#define EEPROM_SIZE 1440
#define ADDR_VALUE 1280    // 4 bytes
#define ADDR_BITLEN 1284   // 2 bytes
#define ADDR_PROTO 1286    // 2 bytes
#define ADDR_FREQ 1288     // 4 bytes 

#define SCREEN_WIDTH  240
#define SCREENHEIGHT 320
#define SCREEN_HEIGHT 320

static bool uiDrawn = false;

#define MAX_NAME_LENGTH 16 // Maximum length for profile name (including null terminator)

// Keyboard layout (4 rows)
const char* keyboardLayout[] = {
  "1234567890",
  "QWERTYUIOP",
  "ASDFGHJKL",
  "ZXCVBNM<-" // '<' for backspace, '-' for clear
};

// Random name suggestions for shuffle
const char* randomNames[] = {
  "Signal", "Remote", "KeyFob", "GateOpener", "DoorLock",
  "RFTest", "Profile", "Control", "Switch", "Beacon"
};
const int numRandomNames = 10;
int randomNameIndex = 0;

// Keyboard dimensions
const int keyWidth = 22;
const int keyHeight = 22;
const int keySpacing = 2;
const int yOffsetStart = 95;

// Cursor blink state
static bool cursorState = true;
static unsigned long lastCursorBlink = 0;
const unsigned long cursorBlinkInterval = 500;

struct Profile {
    uint32_t frequency;
    unsigned long value;
    int bitLength;
    int protocol;
    char name[MAX_NAME_LENGTH]; // Custom name field
};

#define PROFILE_SIZE sizeof(Profile) // Size of the updated Profile struct
#define ADDR_PROFILE_START 1300
#define MAX_PROFILES 5
#define ADDR_PROFILE_COUNT 0 

#define MAX_PROFILES 5         

int profileCount = 0;

RCSwitch mySwitch = RCSwitch();
arduinoFFT FFTSUB = arduinoFFT();

const uint16_t samplesSUB = 256; 
const double FrequencySUB = 5000;

double attenuation_num = 10;

unsigned int sampling_period;
unsigned long micro_s;

double vRealSUB[samplesSUB];
double vImagSUB[samplesSUB];

byte red[128], green[128], blue[128];

unsigned int epochSUB = 0;
unsigned int colorcursor = 2016;

int rssi;

#define RX_PIN 16         
#define TX_PIN 26 

#define BTN_LEFT   4
#define BTN_RIGHT  5
#define BTN_UP     6
#define BTN_DOWN   3

unsigned long receivedValue = 0; 
int receivedBitLength = 0;       
int receivedProtocol = 0;       
const int rssi_threshold = -75; 

static const uint32_t subghz_frequency_list[] = {
    300000000, 303875000, 304250000, 310000000, 315000000, 318000000,  
    390000000, 418000000, 433075000, 433420000, 433920000, 434420000, 
    434775000, 438900000, 868350000, 915000000, 925000000
};

int currentFrequencyIndex = 0; 
int yshift = 20;


void updateDisplay() {
    uiDrawn = false;

    tft.fillRect(0, 40, 240, 40, TFT_BLACK);  
    tft.drawLine(0, 80, 240, 80, TFT_WHITE);

    // Frequency
    tft.setCursor(5, 20 + yshift);
    tft.setTextColor(TFT_CYAN);
    tft.print("Freq:");
    tft.setTextColor(TFT_WHITE);
    tft.setCursor(50, 20 + yshift);
    tft.print(subghz_frequency_list[currentFrequencyIndex] / 1000000.0, 2);
    tft.print(" MHz");
    
    // Bit Length
    tft.setCursor(5, 35 + yshift);
    tft.setTextColor(TFT_CYAN);
    tft.print("Bit:");
    tft.setTextColor(TFT_WHITE);
    tft.setCursor(50, 35 + yshift);
    tft.printf("%d", receivedBitLength);

    // RSSI
    tft.setCursor(130, 35 + yshift);
    tft.setTextColor(TFT_CYAN);
    tft.print("RSSI:");
    tft.setTextColor(TFT_WHITE);
    tft.setCursor(170, 35 + yshift);
    tft.printf("%d", ELECHOUSE_cc1101.getRssi());    

    // Protocol
    tft.setCursor(130, 20 + yshift);
    tft.setTextColor(TFT_CYAN);
    tft.print("Ptc:");
    tft.setTextColor(TFT_WHITE);
    tft.setCursor(170, 20 + yshift);
    tft.printf("%d", receivedProtocol);

    // Received Value
    tft.setCursor(5, 50 + yshift);
    tft.setTextColor(TFT_CYAN);
    tft.print("Val:");
    tft.setTextColor(TFT_WHITE);
    tft.setCursor(50, 50 + yshift);
    tft.print(receivedValue);

    ELECHOUSE_cc1101.setSidle();  
    ELECHOUSE_cc1101.setMHZ(subghz_frequency_list[currentFrequencyIndex] / 1000000.0);
    ELECHOUSE_cc1101.SetRx();     
}


void drawInputField(String& inputName) {
  tft.fillRect(10, 55, 220, 25, TFT_DARKGREY);
  tft.drawRect(9, 54, 222, 27, ORANGE);
  tft.setTextColor(TFT_WHITE);
  tft.setTextSize(2);
  tft.setCursor(15, 60);
  String displayText = inputName;
  if (cursorState) {
    displayText += "|";
  }
  tft.println(displayText);
}

void drawKeyboard(String& inputName) {
  tft.fillRect(0, 37, SCREEN_WIDTH, SCREEN_HEIGHT - 37, TFT_BLACK);

  // Instructional text
  tft.setTextColor(ORANGE);
  tft.setTextSize(1);
  tft.setCursor(1, 235);
  tft.println("[!] Set a name for the saved profile.");
  tft.setCursor(23, 250);
  tft.println("(max 15 chars)");

  tft.setCursor(1, 275);
  tft.println("[!] Shuffle: Suggests random profile");
  tft.setCursor(23, 290);
  tft.println("names for your signal.");

  drawInputField(inputName);

  // Draw keyboard
  int yOffset = yOffsetStart;
  for (int row = 0; row < 4; row++) {
    int xOffset = 1;
    for (int col = 0; col < strlen(keyboardLayout[row]); col++) {
      tft.fillRect(xOffset, yOffset, keyWidth, keyHeight, TFT_DARKGREY);
      tft.setTextColor(TFT_WHITE);
      tft.setTextSize(1);
      tft.setCursor(xOffset + 6, yOffset + 5);
      tft.print(keyboardLayout[row][col]);
      xOffset += keyWidth + keySpacing;
    }
    yOffset += keyHeight + keySpacing;
  }

  // Draw buttons
  tft.setTextColor(ORANGE);
  tft.setTextSize(1);
  tft.setTextDatum(MC_DATUM);

  // Back Button
  tft.fillRoundRect(5, 195, 70, 25, 4, DARK_GRAY);
  tft.drawRoundRect(5, 195, 70, 25, 4, ORANGE);
  tft.drawString("Back", 40, 208);

  // Shuffle Button
  tft.fillRoundRect(85, 195, 70, 25, 4, DARK_GRAY);
  tft.drawRoundRect(85, 195, 70, 25, 4, ORANGE);
  tft.drawString("Shuffle", 120, 208);

  // OK Button
  tft.fillRoundRect(165, 195, 70, 25, 4, DARK_GRAY);
  tft.drawRoundRect(165, 195, 70, 25, 4, ORANGE);
  tft.drawString("OK", 200, 208);

  tft.setTextDatum(TL_DATUM); // Reset to top-left for other text
}

String getUserInputName() {
  String inputName = "";
  bool keyboardActive = true;

  drawKeyboard(inputName);

  while (keyboardActive) {
    // Blink cursor
    if (millis() - lastCursorBlink >= cursorBlinkInterval) {
      cursorState = !cursorState;
      drawInputField(inputName);
      lastCursorBlink = millis();
    }

    if (ts.touched()) {
      TS_Point p = ts.getPoint();
      int x = map(p.x, 300, 3800, 0, SCREEN_WIDTH - 1);
      int y = map(p.y, 3800, 300, 0, SCREEN_HEIGHT - 1);

      // Handle keyboard keys
      int yOffset = yOffsetStart;
      for (int row = 0; row < 4; row++) {
        int xOffset = 1;
        for (int col = 0; col < strlen(keyboardLayout[row]); col++) {
          if (x >= xOffset && x <= xOffset + keyWidth && y >= yOffset && y <= yOffset + keyHeight) {
            char c = keyboardLayout[row][col];
            // Highlight key
            tft.fillRect(xOffset, yOffset, keyWidth, keyHeight, ORANGE);
            tft.setTextColor(TFT_WHITE);
            tft.setTextSize(1);
            tft.setCursor(xOffset + 6, yOffset + 5);
            tft.print(c);
            delay(100); // Visual feedback
            tft.fillRect(xOffset, yOffset, keyWidth, keyHeight, TFT_DARKGREY);
            tft.setTextColor(TFT_WHITE);
            tft.setCursor(xOffset + 6, yOffset + 5);
            tft.print(c);

            if (c == '<') { // Backspace
              if (inputName.length() > 0) {
                inputName = inputName.substring(0, inputName.length() - 1);
              }
            } else if (c == '-') { // Clear
              inputName = "";
            } else if (inputName.length() < MAX_NAME_LENGTH - 1) {
              inputName += c;
            }
            drawInputField(inputName);
            delay(200); // Debounce
          }
          xOffset += keyWidth + keySpacing;
        }
        yOffset += keyHeight + keySpacing;
      }

      // Handle buttons
      if (x >= 5 && x <= 75 && y >= 195 && y <= 210) { // Back
        keyboardActive = false;
        inputName = ""; // Cancel input
        tft.fillScreen(TFT_BLACK);
        updateDisplay();
      }

      if (x >= 85 && x <= 155 && y >= 195 && y <= 210) { // Shuffle
        inputName = randomNames[randomNameIndex];
        randomNameIndex = (randomNameIndex + 1) % numRandomNames;
        drawInputField(inputName);
        delay(200); // Debounce
      }

      if (x >= 165 && x <= 235 && y >= 195 && y <= 210) { // OK
        if (inputName.length() > 0) {
          keyboardActive = false;
          return inputName;
        } else {
          tft.fillRect(10, 80, 220, 10, TFT_BLACK);
          tft.setTextColor(TFT_RED);
          tft.setTextSize(1);
          tft.setCursor(10, 85);
          tft.println("Name cannot be empty!");
          tft.setTextColor(TFT_WHITE);
          delay(500);
          drawInputField(inputName); // Redraw to clear error
          delay(200); // Debounce
        }
      }
    }
    delay(10);
  }
  return inputName; // Return empty string if cancelled
}




void sendSignal() {
  
    mySwitch.disableReceive(); 
    delay(100);
    mySwitch.enableTransmit(TX_PIN); 
    ELECHOUSE_cc1101.SetTx();

    tft.fillRect(0,40,240,37, TFT_BLACK);
    
    tft.setCursor(10, 30 + yshift);
    tft.print("Sending...");
    tft.setCursor(10, 40 + yshift);
    tft.print(receivedValue);

    mySwitch.setProtocol(receivedProtocol);
    mySwitch.send(receivedValue, receivedBitLength); 

    delay(500);
    tft.fillRect(0,40,240,37, TFT_BLACK);
    tft.setCursor(10, 30 + yshift);
    tft.print("Done!");

    ELECHOUSE_cc1101.SetRx(); 
    mySwitch.disableTransmit(); 
    delay(100);
    mySwitch.enableReceive(RX_PIN);
    
    delay(500);
    updateDisplay();
}

void do_sampling() {
  
  micro_s = micros();

  #define ALPHA 0.2  
  float ewmaRSSI = -50;  

for (int i = 0; i < samplesSUB; i++) {
    int rssi = ELECHOUSE_cc1101.getRssi();
    rssi += 100;  

    ewmaRSSI = (ALPHA * rssi) + ((1 - ALPHA) * ewmaRSSI);

    vRealSUB[i] = ewmaRSSI * 2;
    vImagSUB[i] = 1;

    while (micros() < micro_s + sampling_period);
    micro_s += sampling_period;
}

  double mean = 0;
  
  for (uint16_t i = 0; i < samplesSUB; i++)
        mean += vRealSUB[i];
        mean /= samplesSUB;
  for (uint16_t i = 0; i < samplesSUB; i++)
        vRealSUB[i] -= mean;
    
  micro_s = micros();
  
  FFTSUB.Windowing(vRealSUB, samplesSUB, FFT_WIN_TYP_HAMMING, FFT_FORWARD); 
  FFTSUB.Compute(vRealSUB, vImagSUB, samplesSUB, FFT_FORWARD); 
  FFTSUB.ComplexToMagnitude(vRealSUB, vImagSUB, samplesSUB); 

unsigned int left_x = 120;
unsigned int graph_y_offset = 81; 
int max_k = 0;

for (int j = 0; j < samplesSUB >> 1; j++) {
    int k = vRealSUB[j] / attenuation_num; 
    if (k > max_k)
        max_k = k; 
    if (k > 127) k = 127; 

    unsigned int color = red[k] << 11 | green[k] << 5 | blue[k];
    unsigned int vertical_x = left_x + j; 

    tft.drawPixel(vertical_x, epochSUB + graph_y_offset, color); 
}

for (int j = 0; j < samplesSUB >> 1; j++) {
    int k = vRealSUB[j] / attenuation_num;
    if (k > max_k)
        max_k = k;
    if (k > 127) k = 127;

    unsigned int color = red[k] << 11 | green[k] << 5 | blue[k];
    unsigned int mirrored_x = left_x - j; 
    tft.drawPixel(mirrored_x, epochSUB + graph_y_offset, color);
}

  double tattenuation = max_k / 127.0;
  
  if (tattenuation > attenuation_num)
    attenuation_num = tattenuation;
                     
    delay(10);
}

void readProfileCount() {
    EEPROM.get(ADDR_PROFILE_START - sizeof(int), profileCount);
    if (profileCount > MAX_PROFILES || profileCount < 0) {
        profileCount = 0;  
    }
}

void saveProfile() {
    readProfileCount();  

    if (profileCount < MAX_PROFILES) {
        // Get custom name from user
        String customName = getUserInputName();

        tft.setTextSize(1);

        Profile newProfile;
        newProfile.frequency = subghz_frequency_list[currentFrequencyIndex];
        newProfile.value = receivedValue;
        newProfile.bitLength = receivedBitLength;
        newProfile.protocol = receivedProtocol;
        strncpy(newProfile.name, customName.c_str(), MAX_NAME_LENGTH - 1);
        newProfile.name[MAX_NAME_LENGTH - 1] = '\0'; // Ensure null termination

        int addr = ADDR_PROFILE_START + (profileCount * PROFILE_SIZE);
        EEPROM.put(addr, newProfile); 
        EEPROM.commit();

        profileCount++;  

        EEPROM.put(ADDR_PROFILE_START - sizeof(int), profileCount);
        EEPROM.commit();  

        tft.fillScreen(TFT_BLACK);
        tft.setCursor(10, 30 + yshift);
        tft.print("Profile saved!");
        tft.setCursor(10, 40 + yshift);
        tft.print("Name: ");
        tft.print(newProfile.name);
        tft.setCursor(10, 50 + yshift);
        tft.print("Profiles saved: ");
        tft.println(profileCount);

    } else {
        tft.fillScreen(TFT_BLACK);
        tft.setCursor(10, 30 + yshift);
        tft.print("Profile storage full!");
    }
    
    delay(2000);
    updateDisplay();
    float currentBatteryVoltage = readBatteryVoltage();
    drawStatusBar(currentBatteryVoltage, false);
}

void loadProfileCount() {
    EEPROM.get(ADDR_PROFILE_START, profileCount);
    if (profileCount > MAX_PROFILES) {
        profileCount = MAX_PROFILES;  
    }
}

void runUI() {

    #define STATUS_BAR_Y_OFFSET 20
    #define STATUS_BAR_HEIGHT 16
    #define ICON_SIZE 16
