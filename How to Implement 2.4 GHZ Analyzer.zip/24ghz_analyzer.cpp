#include "24ghz_analyzer.h"
#include "shared.h"
#include "Touchscreen.h"

// nRF24L01 pins (configurable)
#define CE_PIN  2
#define CSN_PIN 15

RF24 radio(CE_PIN, CSN_PIN);

namespace _24GHzAnalyzer {

    const int numChannels = 125; // nRF24L01 operates on 125 channels (0-124)
    int rssiValues[numChannels];
    int currentChannel = 0;

    void setup() {
        tft.fillScreen(TFT_BLACK);
        tft.setTextColor(TFT_WHITE);
        tft.setTextSize(1);
        tft.setCursor(0, 0);
        tft.println("2.4GHz Analyzer");

        // Initialize nRF24L01
        if (!radio.begin()) {
            tft.println("radio.begin() failed");
            while (1);
        }
        radio.setPALevel(RF24_PA_LOW);
        radio.stopListening(); // We will be transmitting to read RSSI
    }

    void loop() {
        // Scan channels and read RSSI
        for (int i = 0; i < numChannels; i++) {
            radio.setChannel(i);
            radio.powerUp();
            delayMicroseconds(130); // Allow radio to power up and settle
            rssiValues[i] = radio.getARC(); // Auto Retransmit Count as a proxy for noise/RSSI
            radio.powerDown();
        }

        // Display RSSI values (simple bar graph for now)
        tft.fillRect(0, 20, tft.width(), tft.height() - 20, TFT_BLACK); // Clear previous graph
        int barWidth = tft.width() / numChannels;
        for (int i = 0; i < numChannels; i++) {
            int barHeight = map(rssiValues[i], 0, 15, 0, tft.height() - 20); // Map RSSI to screen height
            tft.fillRect(i * barWidth, tft.height() - barHeight, barWidth, barHeight, TFT_GREEN); // Draw bar
        }

        delay(100); // Update every 100ms
    }

} // namespace _24GHzAnalyzer


