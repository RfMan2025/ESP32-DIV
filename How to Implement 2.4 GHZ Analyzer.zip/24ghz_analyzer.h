#ifndef _24GHZ_ANALYZER_H
#define _24GHZ_ANALYZER_H

#include <Arduino.h>
#include <TFT_eSPI.h>
#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>

extern TFT_eSPI tft;

namespace _24GHzAnalyzer {
    void setup();
    void loop();
    void drawGraph();
    void analyze();
}

#endif // _24GHZ_ANALYZER_H


